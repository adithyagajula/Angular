import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'productFilter'
})
export class ProductFilterPipe implements PipeTransform {

  transform(value,pr) {
    let pro=[];
    for(var i=0;i<value.length;i++){
    if(value[i].name.includes(pr)){
    pro.push(value[i]);
    }
    }
    return pro;
    }
    
   }
