import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-state-cities',
  templateUrl: './state-cities.component.html',
  styleUrls: ['./state-cities.component.css']
})
export class StateCitiesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  state=["telangana", "andhrapradesh", "tamilnadu", "maharashtra"];
  telangana=["karimnagar", "warangal", "hyderabad"];
  andhrapradesh=["vijayawada", "vizag", "tirupati"];
  tamilnadu=["chennai", "madurai", "coimbatore"];
  maharashtra=["mumbai", "pune", "thane"];
}
