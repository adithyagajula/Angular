import { Component, OnInit } from '@angular/core';
import { Product } from '../product';


@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  s;
  languages=['java', 'pega', 'angular', 'react', 'javascript'];
  products:Product[]=[
    {id:1, name:'pen', price:25},
    {id:2, name:'bag', price:1025},
    {id:3, name:'shoes', price:2500}
  ]
}
