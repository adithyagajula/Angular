import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  category=["Electronics", "Grocery"];
  Electronics=["Telivision", "Laptop", "Phone"];
  Grocery=["Soap", "Powder"];
  q;
  pro;
result;
total(){
  if(this.pro=="Telivision"){
  this.result=(this.q)*20000
  }
  else if(this.pro=="Laptop"){
  this.result=(this.q)*30000
  }

else if(this.pro=="Phone"){
  this.result=(this.q)*10000
}
else if(this.pro=="Soap"){
  this.result=(this.q)*40
}
else if(this.pro=="Powder"){
  this.result=(this.q)*90
}
}
}
