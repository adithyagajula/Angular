import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book-my-show',
  templateUrl: './book-my-show.component.html',
  styleUrls: ['./book-my-show.component.css']
})
export class BookMyShowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
t;
result;
total(){
  if(this.t<=10){
  this.result=(this.t)*150
  }
  else
  alert("choose below 10 tickets")
}
}
