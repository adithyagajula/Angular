import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-to-do-list',
  templateUrl: './to-do-list.component.html',
  styleUrls: ['./to-do-list.component.css']
})
export class ToDoListComponent implements OnInit {
    

  constructor() { }

  ngOnInit() {
  }
  taskname=[];
  task;
  add(){
    this.taskname.push(this.task);
  }
  remove(ind){
    this.taskname.splice(ind,1);
  }
}
