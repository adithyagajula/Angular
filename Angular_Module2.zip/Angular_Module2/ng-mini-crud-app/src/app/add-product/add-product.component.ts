import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../products.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  constructor(private ps: ProductsService,private router: Router) { }
  product={
    name:'',
    description:'',
    price:''
  }
  addProduct(){
    this.ps.add(this.product).subscribe(()=>{alert('added...')
  this.router.navigate(['home'])
  })
  }

  ngOnInit() {
  }

}
