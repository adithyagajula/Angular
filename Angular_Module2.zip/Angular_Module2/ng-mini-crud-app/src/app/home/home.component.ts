import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../products.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  products;

  constructor(private ps: ProductsService, private router:Router) { 
    if(localStorage.getItem('user')==null){
      this.router.navigate([''])

    }
    ps.getAll().subscribe((res)=>this.products=res)
  }
  removeProduct(id){
    this.ps.remove(id).subscribe(()=>{alert("deleted..")
  history.go();
  })

  }
  logout(){
    localStorage.clear();
    this.router.navigate([''])

  }


  ngOnInit() {
  }

}
