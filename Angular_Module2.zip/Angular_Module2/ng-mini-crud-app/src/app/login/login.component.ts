import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  username;
  password;

  constructor(private router: Router) { }
  login(){
    if(this.username=='adithya'&& this.password=='123'){
      localStorage.setItem('user',this.username)
      localStorage.setItem('role','admin')
      this.router.navigate(['home'])
    }
    else{
      localStorage.setItem('user',this.username)
      localStorage.setItem('role','customer')
      this.router.navigate(['home'])
    }
  }

  ngOnInit() {
  }

}
