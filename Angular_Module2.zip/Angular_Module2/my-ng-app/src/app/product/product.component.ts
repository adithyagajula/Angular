import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  username: string = "adithya gajula"
  age: number = 21
  langs = ['java', 'pega', 'angular', 'react', 'vue']
  products = [
    { id: 1, name: 'apple', price: 50 },
    { id: 2, name: 'pen', price: 21 },
    { id: 3, name: 'pencil', price: 9 }
  ]

  display() {
    alert("hi..this is adithya")
  }





  
}
