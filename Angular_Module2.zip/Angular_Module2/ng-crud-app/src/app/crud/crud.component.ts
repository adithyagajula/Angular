import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-crud',
  templateUrl: './crud.component.html',
  styleUrls: ['./crud.component.css']
})
export class CrudComponent implements OnInit {

  products;

  constructor(private ps:ProductService) { }

  getAllProducts(){
    this.ps.getAll().subscribe((res) => this.products = res);
  }
addProduct(){
  let p = { name:'pencil', price:10}
  this.ps.addProduct(p).subscribe(() => alert('added....'))
}
updateProduct(){
  let p = { id:3, name:'apple',price:'26'}
  this.ps.updateProduct(p).subscribe(() => alert('added....'))
}
removeProduct(){
  this.ps.remove(4).subscribe(()=>alert('DOne...'))
}
  ngOnInit() {
  }

}
