import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GameCityComponent } from './game-city/game-city.component';
import { PlayComponent } from './play/play.component';
import { SuccessComponent } from './success/success.component';


const routes: Routes = [
  {path:'play/:amount',component:PlayComponent},
  {path:'',component:GameCityComponent},
  {path:'gamecity',component:GameCityComponent},
  {path:'play',component:PlayComponent},
  {path:'success',component:SuccessComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
