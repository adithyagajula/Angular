import { Component, OnInit } from '@angular/core';
import { GameService } from '../game.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-play',
  templateUrl: './play.component.html',
  styleUrls: ['./play.component.css']
})
export class PlayComponent implements OnInit {
  gameList;
  amount;

  constructor(private gs:GameService,private route:ActivatedRoute) { 
    gs.getAll().subscribe((res)=>this.gameList=res)
    route.params.subscribe((para)=>this.amount=para['amount'])
   
  }
  

  ngOnInit() {
  }

}
