import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-game-city',
  templateUrl: './game-city.component.html',
  styleUrls: ['./game-city.component.css']
})
export class GameCityComponent implements OnInit {
  name;
  address;
  amount;
  amount1;

  constructor(private router:Router) { }
  buyCard(){
    this.amount1=this.amount-100;
    
      this.router.navigateByUrl('/play/'+this.amount1)
      
      }
      
    

  ngOnInit() {
  }

}
