import { Component, OnInit } from '@angular/core';
import { MovieService } from '../movie.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  categories=['drama','fiction','satire']

  constructor(private ms: MovieService) { }
  movies={
    name:'',
    rating:'',
    category:''
  }
  addMovie(){
    this.ms.add(this.movies).subscribe(()=>{alert('added...')
  })
  }



  ngOnInit() {
  }

}
