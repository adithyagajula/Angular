import { Component, OnInit } from '@angular/core';
import { MovieService } from '../movie.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  category;
  movies;
  categories=['drama','fiction','satire']

  constructor(private ms: MovieService) {}
    searchMovie(){
      this.ms.getAll().subscribe((res)=>this.movies=res)

    }
    
   

  ngOnInit() {
  }

}