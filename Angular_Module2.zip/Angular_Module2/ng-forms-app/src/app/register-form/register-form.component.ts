import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-register-form',
  templateUrl: './register-form.component.html',
  styleUrls: ['./register-form.component.css']
})
export class RegisterFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  myForm=new FormGroup({
    username: new FormControl('',Validators.required),
    password: new FormControl('',Validators.required),
    email: new FormControl('',Validators.required),
    lan: new FormControl('',Validators.required),
    sex: new FormControl('',Validators.required),
    check: new FormControl('',Validators.requiredTrue)
  
  })
  languages=['java','python','c','angular']
  error_messages={
    'username' : [
      {type:'required',message: 'feild should not be empty'}
      
    ],
    'password' : [
      {type: 'required',message: 'feild should not be empty'}
    ],
    'email' : [
      {type: 'required',message: 'feild should not be empty'}
    ],
    'lan' : [
      {type: 'required',message: 'feild should not be empty'}
    ],
    'sex' : [
      {type: 'required',message: 'feild should not be empty'}
    ],
    'check' : [
      {type: 'required',message: 'Please select '}
    ]

  }
  

}
