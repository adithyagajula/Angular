import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lab12',
  templateUrl: './lab12.component.html',
  styleUrls: ['./lab12.component.css']
})
export class Lab12Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  id;
  name;
  salary;
  dep;

  add(){
    alert(this.id+" "+this.name+" "+this.salary+" "+this.dep)
  }
}
