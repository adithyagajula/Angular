import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lab21',
  templateUrl: './lab21.component.html',
  styleUrls: ['./lab21.component.css']
})
export class Lab21Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }
id;
name;
salary;
dept;
d=new Date();
employee=[];
display(){
this.employee.push({id:this.id, name:this.name, salary:this.salary, dept:this.dept})
}
delete(ind){
  this.employee.splice(ind,1)

}
}
