import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
@Component({
  selector: 'app-lab3',
  templateUrl: './lab3.component.html',
  styleUrls: ['./lab3.component.css']
})
export class Lab3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  pId;
  pname;
  pcost;
  rad;
  pcat;
  check;
  onFormSubmit(){
    console.log(this.pId+" "+this.pname+" "+this.pcost+" "+this.rad+" "+this.pcat+" "+this.check)
  }

  myForm= new FormGroup(
    {
    pId: new FormControl('', [Validators.required]),
    pname: new FormControl('', [Validators.required]),
    pcost: new FormControl('', [Validators.required]),
    rad: new FormControl('',[Validators.required] ),
    pcat: new FormControl('',[Validators.required]),
    check: new FormControl('',[Validators.requiredTrue])
    }
    )
    error_messages={
    
    'pId': [
    { type: 'required', message:'Field should not be empty'}
    ],
    'pname': [
    { type: 'required', message:'Field should not be empty'}
    ],
    'pcost': [
    { type: 'required', message:'Field should not be empty'}
    ],
    'rad': [
    { type: 'required', message:'select'}
    ],
    'pcat': [
    { type: 'required', message:'Field should not be empty'}
    ],
    'check': [
    { type: 'required', message:'Field should not be empty'}
    ]
    }
    
}
