import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'search'
})
export class SearchPipe implements PipeTransform {

  transform(value,a,b,c,d){
    // let book=[];
    // for(var i=0;i<value.length;i++){
    //   if((value[i].id==a)||value[i].title.includes(b)||value[i].author.includes(c)||(value[i].year==d)){
    //     book.push(value[i])
    //   }
    // }
    if(a!=''){
      return value.filter((booklist)=>booklist.id==a)
    }
    else if(b!=''){
      return value.filter((booklist)=>booklist.title.includes(b))
    }
    else if(c!=''){
      return value.filter((booklist)=>booklist.author.includes(c))
    }
    else if(d!=''){
      return value.filter((booklist)=>booklist.year==d)
    }
// else{
//     return value;
// }
  }

}
