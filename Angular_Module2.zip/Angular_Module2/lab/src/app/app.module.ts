import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { Lab12Component } from './lab12/lab12.component';
import {FormsModule, ReactiveFormsModule} from'@angular/forms';
import { Lab21Component } from './lab21/lab21.component';
import { Lab42Component } from './lab42/lab42.component';
import { SearchPipe } from './search.pipe';
import { Lab3Component } from './lab3/lab3.component';
    






@NgModule({
  declarations: [
    AppComponent,
    Lab12Component,
    Lab21Component,
    Lab42Component,
    SearchPipe,
    Lab3Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
